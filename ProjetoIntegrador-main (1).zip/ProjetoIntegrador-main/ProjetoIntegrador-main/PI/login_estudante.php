<?php
// Este arquivo não é mais usado para processar login, o formulário agora envia para login.php
// Mantido aqui para referência ou caso haja algum HTML associado a ele no futuro.
// O processamento de login de estudante foi movido para login.php
?>
