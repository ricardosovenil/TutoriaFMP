<?php
error_log("TESTE DE LOG: Esta é uma mensagem de teste do PHP.");
echo "Verifique o log de erros do PHP para a mensagem de teste.";
?> 